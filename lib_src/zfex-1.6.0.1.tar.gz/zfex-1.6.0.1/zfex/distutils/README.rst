ccompilercapabilities.py
========================

Source: `github.com/mayeut/pybase64 by Matthieu Darbois <https://github.com/mayeut/pybase64/raw/b89329d9d818cd8609c294cff1ccbf4c7c759aba/pybase64/distutils/ccompilercapabilities.py>`__

`License: BSD 2-Clause <LICENSE.ccompilercapabilities.py>`__
